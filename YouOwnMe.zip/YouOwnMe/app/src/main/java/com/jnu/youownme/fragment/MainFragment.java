package com.jnu.youownme.fragment;

import android.app.AlertDialog;
import android.content.ContentValues;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.database.sqlite.SQLiteDatabase;
import android.icu.text.SimpleDateFormat;
import android.os.Build;
import android.os.Bundle;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.annotation.RequiresApi;
import androidx.fragment.app.Fragment;

import android.os.Handler;
import android.os.Message;
import android.util.Log;
import android.view.ContextMenu;
import android.view.LayoutInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.CalendarView;
import android.widget.ListView;
import android.widget.Spinner;
import android.widget.Toast;

import com.getbase.floatingactionbutton.FloatingActionButton;

import com.getbase.floatingactionbutton.FloatingActionsMenu;
import com.jnu.youownme.Callbacks;
import com.jnu.youownme.EditList;
import com.jnu.youownme.MainActivity;
import com.jnu.youownme.R;
import com.jnu.youownme.model.Present;
import com.jnu.youownme.model.PresentAdapter;

import java.text.ParseException;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;

import static android.app.Activity.RESULT_OK;
import static com.jnu.youownme.DatabaseHelper.TABLE_NAME;

/**
 * A simple {@link Fragment} subclass.
 * Use the {@link MainFragment#newInstance} factory method to
 * create an instance of this fragment.
 */
public class MainFragment extends Fragment {

    // TODO: Rename parameter arguments, choose names that match
    // the fragment initialization parameters, e.g. ARG_ITEM_NUMBER
    private static final String ARG_PARAM1 = "param1";
    private static final String ARG_PARAM2 = "param2";
    public static final int Receive = 100;
    public static final int Given = 101;
    public static final int REQUEST_CODE_GIVE = 1;
    public static final int REQUEST_CODE_RECEIVED = 2;
    public static final int DELETE_PRESENT = 1;
    public static final int UPDATE_PRESENT = 2;
    public static final int REQUEST_CODE_UPDATE = 3;

    // TODO: Rename and change types of parameters
    private String mParam1;
    private String mParam2;

    private CalendarView calendarView;
    private ListView listView;
    private FloatingActionButton fab_given;
    private FloatingActionButton fab_received;
    private Spinner spinner;
    private FloatingActionsMenu floatingActionsMenu;
    private ArrayList<Present> presents;
    private Date select_date;
    private ArrayList<Present>today_presents=new ArrayList<>();
    private int show_type=0;

    private Intent intent;
    private Bundle bundle;
    private ArrayList list;
    private PresentAdapter presentAdapter;
    private Callbacks callbacks;

    private SQLiteDatabase db;


    public MainFragment() {
        // Required empty public constructor

    }

    @RequiresApi(api = Build.VERSION_CODES.N)
    @Override
    public void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);

        if(resultCode==RESULT_OK) {
            int money=Integer.valueOf(data.getStringExtra("new_money")).intValue();
            //int money=100;
            String reason=data.getStringExtra("new_reason");
            //SimpleDateFormat simpleDateFormat = new SimpleDateFormat("yyyy-MM-dd");//注意月份是MM
        /*try {
            date = simpleDateFormat.parse(data.getStringExtra("new_date"));
        } catch (ParseException e) {
            e.printStackTrace();
        }*/
            String name=data.getStringExtra("new_name");
            ContentValues values = new ContentValues();
            int id;
            if(presents.isEmpty()){
                id=0;
            }
            else
                id=presents.get(presents.size()-1).getId()+1;
            switch (requestCode) {

                case REQUEST_CODE_GIVE:


                    Present givepresent=new Present(money,reason,select_date,name,Given,id);
                    presents.add(givepresent);
                    values.put("money",money);
                    values.put("reason", reason);
                    values.put("day",select_date.getDate());
                    values.put("month",select_date.getMonth());
                    values.put("year",select_date.getYear());
                    values.put("name",name);
                    values.put("type",Given);
                    values.put("id",presents.indexOf(givepresent));
                    db.insert(TABLE_NAME, null, values);
                    break;
                case REQUEST_CODE_RECEIVED:
                    Present receivedpresent=new Present(money,reason,select_date,name,Given,id);
                    presents.add(receivedpresent);
                    values.put("money",money);
                    values.put("reason", reason);
                    values.put("day",select_date.getDate());
                    values.put("month",select_date.getMonth());
                    values.put("year",select_date.getYear());
                    values.put("name",name);
                    values.put("type",Receive);
                    values.put("id",presents.indexOf(receivedpresent));
                    db.insert(TABLE_NAME, null, values);
                    break;
                case REQUEST_CODE_UPDATE:
                    values.put("money",money);
                    values.put("reason", reason);
                    values.put("day",select_date.getDate());
                    values.put("month",select_date.getMonth());
                    values.put("year",select_date.getYear());
                    values.put("name",name);
                    id=intent.getIntExtra("id",-1);
                    if(id>=0){
                        db.update(TABLE_NAME,values,"id=?",new String[]{String.valueOf(id)});
                    }
                    for(int i=0;i<presents.size();i++){
                        if(presents.get(i).getId()==id){
                            presents.get(i).setName(name);
                            presents.get(i).setMoney(money);
                            presents.get(i).setReason(reason);
                            break;
                        }
                    }
                default:
                    break;
            }
            callbacks.onCallback(presents);
        }
    }

    @Override
    public void onAttach(@NonNull Context context) {
        super.onAttach(context);
        if(context instanceof Callbacks)
            //因为acitvity实现了Callbacks 接口，所以可以通过强转activity来实例化callbacks
            callbacks = (Callbacks) context;
    }

   /* public MainFragment(ArrayList<Present> presents) {
        this.presents = presents;
    }*/

    /**
     * Use this factory method to create a new instance of
     * this fragment using the provided parameters.
     *
     * @param param1 Parameter 1.
     * @param param2 Parameter 2.
     * @return A new instance of fragment MainFragment.
     */
    // TODO: Rename and change types and number of parameters
    public static MainFragment newInstance(String param1, String param2) {
        MainFragment fragment = new MainFragment();
        Bundle args = new Bundle();
        args.putString(ARG_PARAM1, param1);
        args.putString(ARG_PARAM2, param2);
        fragment.setArguments(args);
        return fragment;
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        if (getArguments() != null) {
            mParam1 = getArguments().getString(ARG_PARAM1);
            mParam2 = getArguments().getString(ARG_PARAM2);
        }
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        /*bundle=getArguments();
        list = bundle.getParcelableArrayList("list");
        presents= (ArrayList<Present>) list.get(0);*/

        db= MainActivity.dbHelper.getWritableDatabase();

        View main_view=inflater.inflate(R.layout.fragment_main, container, false);
        calendarView=main_view.findViewById(R.id.calendar);
        listView=main_view.findViewById(R.id.present_list);
        fab_given =main_view.findViewById(R.id.fab_given);
        fab_received=main_view.findViewById(R.id.fab_received);
        floatingActionsMenu=main_view.findViewById(R.id.fab_menu);
        spinner=main_view.findViewById(R.id.spinner);

        this.registerForContextMenu(listView);


        intent=new Intent(this.getActivity(), EditList.class);

        Calendar calendar = Calendar.getInstance();
        int now_year = calendar.get(Calendar.YEAR)-1900;
        int now_month = calendar.get(Calendar.MONTH);
        int now_day = calendar.get(Calendar.DAY_OF_MONTH);
        select_date=new Date(now_year,now_month,now_day);

        presentAdapter=new PresentAdapter(getContext(), R.layout.list_view_item_present,today_presents);
        listView.setAdapter(presentAdapter);

        Handler handler=new Handler(){
            public void handleMessage(Message msg){
                presentAdapter.notifyDataSetChanged();
            };
        };
        load(handler,show_type);

        calendarView.setOnDateChangeListener((view, year, month, dayOfMonth) -> {
            //Log.i("mymess",year+" ");
            select_date =new Date(year-1900,month,dayOfMonth);

            load(handler,show_type);

            //Log.i("mymess",select_date.getYear()+" ");

        });

        fab_given.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                //intent.putExtra("selected_date",select_date.toString());
                intent.putExtra("name","Name");
                intent.putExtra("reason","reason");
                intent.putExtra("money",0);
                intent.putExtra("id",-1);
                startActivityForResult(intent, REQUEST_CODE_GIVE);
            }
        });

        fab_received.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                //intent.putExtra("selected_date",select_date.toString());
                intent.putExtra("name","Name");
                intent.putExtra("reason","reason");
                intent.putExtra("money",0);
                intent.putExtra("id",-1);
                startActivityForResult(intent, REQUEST_CODE_RECEIVED);
            }
        });

        spinner.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener(){

            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                load(handler,position);
                show_type=position;
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {
                load(handler,0);
                show_type=0;
            }

        });

        return main_view;
    }

    @Override
    public void onCreateContextMenu(@NonNull ContextMenu menu, @NonNull View v, @Nullable ContextMenu.ContextMenuInfo menuInfo) {
        super.onCreateContextMenu(menu, v, menuInfo);
        //获取适配器
        AdapterView.AdapterContextMenuInfo info=(AdapterView.AdapterContextMenuInfo) menuInfo;
        //设置标题
        menu.setHeaderTitle(presents.get(info.position).getName());
        //menu.setHeaderIcon(R.drawable.ic_launcher);
        menu.add(0, 1, 0, "删除");
        menu.add(0, 2,0,"修改");

    }

    @Override
    public boolean onContextItemSelected(@NonNull MenuItem item) {
        switch (item.getItemId()){
            case DELETE_PRESENT:
                android.app.AlertDialog.Builder builder = new AlertDialog.Builder(this.getContext()); //***** //创建 一个提示对话框的构造者对象
                builder.setTitle("删除");//设置弹出对话框的标题
                builder.setMessage("您确定要删除？");//设置弹出对话框的内容
                builder.setCancelable(false);//能否被取消
                builder.setPositiveButton("确定", (dialog, which) -> {
                    AdapterView.AdapterContextMenuInfo info=(AdapterView.AdapterContextMenuInfo)item.getMenuInfo();
                    for(int i=0;i<presents.size();i++){
                        if(today_presents.get(info.position).getId()==presents.get(i).getId()){
                            presents.remove(i);
                            int id=today_presents.get(info.position).getId();
                            db.delete(TABLE_NAME, "id=?", new String[]{String.valueOf(id)});
                        }
                    }
                    callbacks.onCallback(presents);
                    dialog.cancel();
                }).setNegativeButton("取消", (dialog, which) -> dialog.cancel());  //正面的按钮（肯定）
                //反面的按钮（否定)

                builder.show();


                break;
            case UPDATE_PRESENT:
                AdapterView.AdapterContextMenuInfo info=(AdapterView.AdapterContextMenuInfo)item.getMenuInfo();
                intent.putExtra("name",today_presents.get(info.position).getName());
                intent.putExtra("reason",today_presents.get(info.position).getReason());
                intent.putExtra("money",today_presents.get(info.position).getMoney());
                intent.putExtra("id",today_presents.get(info.position).getId());
                startActivityForResult(intent, REQUEST_CODE_UPDATE);
                break;
        }
        return super.onContextItemSelected(item);
    }

    void load(Handler handler,int type){
        new Thread(new Runnable() {
            @Override
            public void run() {
                bundle=getArguments();
                list = bundle.getParcelableArrayList("list");
                presents= (ArrayList<Present>) list.get(0);
                today_presents.clear();
                switch(type){
                    case 0:
                        for(int i=0;i<presents.size();i++) {
                            if(presents.get(i).getDate().equals(select_date)){
                                if(!today_presents.contains(presents.get(i))){
                                    today_presents.add(presents.get(i));
                                }
                            }
                            else {
                                today_presents.remove(presents.get(i));
                            }
                        }
                        break;
                    case 1:
                        for(int i=0;i<presents.size();i++) {
                            if(presents.get(i).getDate().equals(select_date)&&presents.get(i).getType()==Receive){
                                if(!today_presents.contains(presents.get(i))){
                                    today_presents.add(presents.get(i));
                                }
                            }
                            else {
                                today_presents.remove(presents.get(i));
                            }
                        }
                        break;
                    case 2:
                        for(int i=0;i<presents.size();i++) {
                            if(presents.get(i).getDate().equals(select_date)&&presents.get(i).getType()==Given){
                                if(!today_presents.contains(presents.get(i))){
                                    today_presents.add(presents.get(i));
                                }
                            }
                            else {
                                today_presents.remove(presents.get(i));
                            }
                        }
                        break;
                }

                handler.sendEmptyMessage(1);
            }
        }).start();
    }


}