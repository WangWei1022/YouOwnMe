package com.jnu.youownme;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.util.Log;

import com.jnu.youownme.model.Present;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;

public class DatabaseHelper extends SQLiteOpenHelper {

    public static final String DB_NAME="Presents.db";
    public static final int VERSION=1;
    public static final String TABLE_NAME="Present";
    //建表语句
    public static final String CREATE_Present ="create table Present(" +
            "id int,"+
            "money int," +
            "reason String," +
            "day int,"+
            "month int,"+
            "year int,"+
            "name String,"+
            "type int)";

    private Context mContext;
    SQLiteDatabase db=this.getWritableDatabase();

    public DatabaseHelper(Context context, String name,
                          SQLiteDatabase.CursorFactory factory, int version){
        super(context,name,factory,version);
        mContext=context;

    }
    @Override
    public void onCreate(SQLiteDatabase db) {

        db.execSQL(CREATE_Present);
        Log.i("mymess","database");
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {

    }


    /*
    public ArrayList<Present> getPresentArray() throws ParseException {
        ArrayList<Present> presentArrayList=new ArrayList<>();
        //查询数据库，将title一列添加到列表项目中
        Cursor cursor=db.query(TABLE_NAME,null,null,null,null,null,null);
        if(cursor.moveToFirst()){
            int money;
            String reason;
            Date date;
            String name;
            int type;
            do{
                money=cursor.getInt(cursor.getColumnIndex("money"));
                reason=cursor.getString(cursor.getColumnIndex("reason"));
                SimpleDateFormat simpleDateFormat=new SimpleDateFormat("yyyy-MM-dd");
                date=simpleDateFormat.parse(cursor.getString(cursor.getColumnIndex("date")));
                name=cursor.getString(cursor.getColumnIndex("name"));
                type=cursor.getInt(cursor.getColumnIndex("type"));
                presentArrayList.add(new Present(money,  reason,  date, name, type));
            }while(cursor.moveToNext());
        }
        cursor.close();
        return presentArrayList;
    }

     */


}
