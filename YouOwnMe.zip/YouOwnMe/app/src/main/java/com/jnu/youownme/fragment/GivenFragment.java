package com.jnu.youownme.fragment;

import android.content.Context;
import android.os.Bundle;

import androidx.annotation.NonNull;
import androidx.fragment.app.Fragment;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.ListView;
import android.widget.TextView;

import com.jnu.youownme.Callbacks;
import com.jnu.youownme.R;
import com.jnu.youownme.model.Present;
import com.jnu.youownme.model.PresentAdapter;

import java.util.ArrayList;

/**
 * A simple {@link Fragment} subclass.
 * Use the {@link GivenFragment#newInstance} factory method to
 * create an instance of this fragment.
 */
public class GivenFragment extends Fragment {


    public static final int Given = 101;

    // TODO: Rename parameter arguments, choose names that match
    // the fragment initialization parameters, e.g. ARG_ITEM_NUMBER
    private static final String ARG_PARAM1 = "param1";
    private static final String ARG_PARAM2 = "param2";

    // TODO: Rename and change types of parameters
    private String mParam1;
    private String mParam2;

    private ArrayList<Present> presents;
    private ListView listView;
    private TextView search;
    private Button button;
    private ArrayList<Present> given_presents=new ArrayList<>();

    Bundle bundle;
    ArrayList list;
    Callbacks callbacks;

    public GivenFragment() {
        // Required empty public constructor
    }

    @Override
    public void onAttach(@NonNull Context context) {
        super.onAttach(context);
        if(context instanceof Callbacks)
            //因为acitvity实现了Callbacks 接口，所以可以通过强转activity来实例化callbacks
            callbacks = (Callbacks) context;
    }

    /*public GivenFragment(ArrayList<Present> presents) {
        this.presents = presents;
    }*/

    /**
     * Use this factory method to create a new instance of
     * this fragment using the provided parameters.
     *
     * @param param1 Parameter 1.
     * @param param2 Parameter 2.
     * @return A new instance of fragment GivenFragment.
     */
    // TODO: Rename and change types and number of parameters
    public static GivenFragment newInstance(String param1, String param2) {
        GivenFragment fragment = new GivenFragment();
        Bundle args = new Bundle();
        args.putString(ARG_PARAM1, param1);
        args.putString(ARG_PARAM2, param2);
        fragment.setArguments(args);
        return fragment;
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        if (getArguments() != null) {
            mParam1 = getArguments().getString(ARG_PARAM1);
            mParam2 = getArguments().getString(ARG_PARAM2);
        }
    }

    @Override
    public void onStart() {
        super.onStart();
        search.setText("");
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment

        bundle=getArguments();
        list = bundle.getParcelableArrayList("list");
        presents= (ArrayList<Present>) list.get(0);

        View view=inflater.inflate(R.layout.fragment_given, container, false);
        listView=view.findViewById(R.id.given_list);
        search=view.findViewById(R.id.edit_search);
        search.setText("");
        button=view.findViewById(R.id.button_search);

        given_presents.clear();
        for(int i=0;i<presents.size();i++){
            if(presents.get(i).getType()==Given&&!given_presents.contains(presents.get(i))){
                given_presents.add(presents.get(i));
            }
        }
        PresentAdapter presentAdapter=new PresentAdapter(getContext(), R.layout.list_view_item_present,given_presents);
        listView.setAdapter(presentAdapter);

        button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String search_text=search.getText().toString();
                if(search_text!=null){
                    given_presents.clear();
                    for(int i=0;i<presents.size();i++){
                        if(presents.get(i).getType()==Given&&!given_presents.contains(presents.get(i))){
                            if(presents.get(i).getName().indexOf(search_text)!=-1||presents.get(i).getReason().indexOf(search_text)!=-1){
                                given_presents.add(presents.get(i));
                            }
                        }
                    }
                }
                presentAdapter.notifyDataSetChanged();
            }
        });
        return view;
    }


}