package com.jnu.youownme;

import com.jnu.youownme.model.Present;

import java.util.ArrayList;

public interface Callbacks{
    public void onCallback(ArrayList<Present> presents);
}