package com.jnu.youownme;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;


public class EditList extends AppCompatActivity {

    private TextView name,money,reason;
    private Button button_ok,button_no;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_edit_list);
        name=this.findViewById(R.id.edit_name);
        money=this.findViewById(R.id.edit_money);
        reason=this.findViewById(R.id.edit_reason);
        //date=this.findViewById(R.id.edit_date);
        button_ok=this.findViewById(R.id.button_ok);
        button_no=this.findViewById(R.id.button_no);


        Intent intent=new Intent();
        //date.setText(getIntent().getStringExtra("selected_date"));

        name.setText(getIntent().getStringExtra("name"));
        money.setText(String.valueOf(getIntent().getIntExtra("money",0)));
        reason.setText(getIntent().getStringExtra("reason"));

        button_ok.setOnClickListener(new View.OnClickListener() {   //按下确定按钮
            @Override
            public void onClick(View v) {

                intent.putExtra("new_name",name.getText().toString());
                intent.putExtra("new_money",money.getText().toString());
                intent.putExtra("new_reason",reason.getText().toString());
                //intent.putExtra("new_date",date.getText().toString());
                setResult(RESULT_OK,intent);
                finish();
            }
        });
        button_no.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                setResult(RESULT_CANCELED,intent);
                finish();
            }
        });
    }
}