package com.jnu.youownme;

import androidx.annotation.RequiresApi;
import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.Fragment;
import androidx.viewpager.widget.ViewPager;

import android.annotation.SuppressLint;
import android.content.ContentValues;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.icu.text.SimpleDateFormat;
import android.os.Build;
import android.os.Bundle;
import android.util.Log;

import com.google.android.material.bottomnavigation.BottomNavigationView;
import com.jnu.youownme.fragment.GivenFragment;
import com.jnu.youownme.fragment.MainFragment;
import com.jnu.youownme.fragment.ReceivedFragment;
import com.jnu.youownme.model.Present;

import java.text.ParseException;
import java.util.ArrayList;
import java.util.Date;

import static com.jnu.youownme.DatabaseHelper.DB_NAME;
import static com.jnu.youownme.DatabaseHelper.TABLE_NAME;
import static com.jnu.youownme.DatabaseHelper.VERSION;

public class MainActivity extends AppCompatActivity implements Callbacks {

    public static final int Receive = 100;
    public static final int Given = 101;

    public static DatabaseHelper dbHelper;
    private SQLiteDatabase db;

    ArrayList<Present> presents=new ArrayList<>();
    MainFragment home;
    GivenFragment given;
    ReceivedFragment received;

    @SuppressLint("NonConstantResourceId")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        //Log.i("mymess:","okk");


        dbHelper=new DatabaseHelper(MainActivity.this,DB_NAME,null,VERSION);
        dbHelper.getWritableDatabase();

        try {
            init();
        } catch (ParseException e) {
            e.printStackTrace();
        }
        Bundle bundle=new Bundle();
        ArrayList list=new ArrayList();
        list.add(presents);
        bundle.putParcelableArrayList("list",list);

        home=new MainFragment();
        home.setArguments(bundle);
        given=new GivenFragment();
        given.setArguments(bundle);
        received=new ReceivedFragment();
        received.setArguments(bundle);


        MyPagerAdapter myPagerAdapter=new MyPagerAdapter(getSupportFragmentManager());

        ArrayList<Fragment> datas= new ArrayList<>();
        datas.add(given);
        datas.add(home);
        datas.add(received);
        myPagerAdapter.setData(datas);

        ArrayList<String>titles= new ArrayList<>();
        titles.add("主页");
        titles.add("随礼");
        titles.add("收礼");
        myPagerAdapter.setTitles(titles);

        ViewPager viewPager=findViewById(R.id.viewpager);
        viewPager.setAdapter(myPagerAdapter);
        viewPager.setCurrentItem(1);


        BottomNavigationView bottomNavigationView=findViewById(R.id.nav_view);
        bottomNavigationView.setSelectedItemId(R.id.navigation_home);
        bottomNavigationView.setOnNavigationItemSelectedListener((menuItem)->{
            switch (menuItem.getItemId()){
                case R.id.navigation_home:
                    viewPager.setCurrentItem(1);
                    break;
                case R.id.navigation_given:
                    viewPager.setCurrentItem(0);
                    break;
                case R.id.navigation_received:
                    viewPager.setCurrentItem(2);
                    break;
            }
            return true;
        });



    }


    private void init() throws ParseException {


        db=dbHelper.getWritableDatabase();
         /* db.execSQL("drop table present");
        db.execSQL("create table Present(" +
                "id int,"+
                "money int," +
                "reason String," +
                "day int,"+
                "month int,"+
                "year int,"+
                "name String,"+
                "type int)");

         */
        /*
        ContentValues values = new ContentValues();
        values.put("money", 101);
        values.put("reason", "reason");
        values.put("date","2000-10-22");
        values.put("name","name");
        values.put("type",Receive);
        db.insert(TABLE_NAME, null, values);

         */
        /*
        db.execSQL("drop table Present");
        db.execSQL("create table Present(" +
                "money int," +
                "reason String," +
                "day int,"+
                "month int,"+
                "year int,"+
                "name String,"+
                "type int)");

         */
        getPresentArray();
    }



    @Override
    public void onCallback(ArrayList<Present> new_presents) {
/*
        for(int i=0;i<new_presents.size();i++){
            if(!this.presents.contains(new_presents.get(i))){

                ContentValues values = new ContentValues();

                values.put("money", new_presents.get(i).getMoney());
                values.put("reason", new_presents.get(i).getReason());
                values.put("day",new_presents.get(i).getDate().getDay());
                values.put("month",new_presents.get(i).getDate().getMonth());
                values.put("year",new_presents.get(i).getDate().getYear());
                values.put("name",new_presents.get(i).getName());
                values.put("type",new_presents.get(i).getType());
                db.insert(TABLE_NAME, null, values);


                Log.i("mymess","date++");

                values.put("money", 100);
                values.put("reason", "reason");
                values.put("date","1999-10-30");
                values.put("name","name");
                values.put("type",Receive);
                db.insert(TABLE_NAME, null, values);


            }

        }

 */
        //this.new_presents=new_presents;

        try {
            init();
        } catch (ParseException e) {
            e.printStackTrace();
        }


        Bundle bundle=new Bundle();
        ArrayList list=new ArrayList();
        list.add(this.presents);
        bundle.putParcelableArrayList("list",list);

        home.setArguments(bundle);
        Log.i("mymess","date++");
        given.setArguments(bundle);
        received.setArguments(bundle);




    }




    public void getPresentArray()  {
        //查询数据库，将title一列添加到列表项目中
        Cursor cursor=db.query(TABLE_NAME,null,null,null,null,null,null);
        presents.clear();
        if(cursor.moveToFirst()){
            int money;
            String reason;
            Date date;
            String name;
            int day,month,year;
            int type;
            int id;
            do{
                money=cursor.getInt(cursor.getColumnIndex("money"));
                reason=cursor.getString(cursor.getColumnIndex("reason"));
                //date=cursor.getString(cursor.getColumnIndex("date"));
                day=cursor.getInt(cursor.getColumnIndex("day"));
                month=cursor.getInt(cursor.getColumnIndex("month"));
                year=cursor.getInt(cursor.getColumnIndex("year"));
                name=cursor.getString(cursor.getColumnIndex("name"));
                type=cursor.getInt(cursor.getColumnIndex("type"));
                date=new Date(year,month,day);
                id=cursor.getInt(cursor.getColumnIndex("id"));
                presents.add(new Present(money,  reason,  date, name, type,id));
            }while(cursor.moveToNext());
        }
        cursor.close();
        return ;
    }
}