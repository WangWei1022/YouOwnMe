package com.jnu.youownme;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;

public class WelcomeActvity extends AppCompatActivity {

    private final Handler handler = new Handler(){
        public void handleMessage(Message msg){
            super.handleMessage(msg);
            Intent intent = new Intent(WelcomeActvity.this,MainActivity.class);    //收到消息后跳转
            startActivity(intent);
            WelcomeActvity.this.finish();
        }
    };

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_welcome_actvity);
        handler.sendEmptyMessageDelayed(0,3000);        //  延迟3秒后发送一个空消息
    }
}