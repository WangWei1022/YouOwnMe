package com.jnu.youownme.model;

import android.icu.text.SimpleDateFormat;

import java.io.Serializable;
import java.text.ParseException;
import java.util.Calendar;
import java.util.Date;
public class Present implements Serializable {
    private int money;
    private String reason;
    private Date date;
    private String name;
    private int type;
    private int id;

    public Present(int money, String reason, Date date,String name,int type,int id) {
        this.money = money;
        this.reason = reason;
        this.date = date;
        this.name=name;
        this.type=type;
        this.id=id;
    }



    public int getMoney() {
        return money;
    }

    public void setMoney(int money) {
        this.money = money;
    }

    public String getReason() {
        return reason;
    }

    public void setReason(String reason) {
        this.reason = reason;
    }

    public Date getDate() {
        return date;
    }

    public void setDate(Date date) {
        this.date = date;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public int getType() {
        return type;
    }

    public void setType(int type) {
        this.type = type;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }
}
