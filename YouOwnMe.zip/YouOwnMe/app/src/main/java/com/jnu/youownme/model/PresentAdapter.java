package com.jnu.youownme.model;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.TextView;

import androidx.annotation.NonNull;

import com.jnu.youownme.R;

import java.util.List;

public class PresentAdapter extends ArrayAdapter{

    private int resourceId;

    public PresentAdapter(Context context, int resource, List objects) {
        super(context, resource, objects);
        resourceId = resource;
    }

    @NonNull
    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        Present present = (Present)getItem(position);//获取当前项的实例
        View view = LayoutInflater.from(getContext()).inflate(resourceId, parent, false);
        ((TextView) view.findViewById(R.id.present_name)).setText(present.getName());
        ((TextView) view.findViewById(R.id.present_reason)).setText(present.getReason());
        ((TextView) view.findViewById(R.id.present_money)).setText("￥"+String.valueOf(present.getMoney()));
        int year=present.getDate().getYear()+1900;
        int month=present.getDate().getMonth()+1;
        int day=present.getDate().getDate();

        String date= year +"-"+ month +"-"+ day;
        ((TextView) view.findViewById(R.id.present_date)).setText(date);
        return view;
    }
}